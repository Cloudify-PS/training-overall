#!/bin/bash
sudo update-rc.d postgresql disable
sudo apt-get remove -y postgres*