#!/bin/bash
sudo service postgresql start