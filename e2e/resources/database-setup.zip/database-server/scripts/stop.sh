#!/bin/bash
sudo service postgresql stop