#!/bin/bash
echo "Downloading packages from repos"
sudo apt-get update -y
sudo apt-get install -y postgresql postgresql-contrib